FileOrganizer v1.0

제작: @youbuddy_day · youbuddy · 2026

[사용 방법]
1. FileOrganizer.exe 더블클릭
2. 정리할 폴더 선택 (기본: 바탕화면)
3. 분류 규칙 설정
4. 정리 실행

- 설정 초기화 가능

[주의]
Windows SmartScreen 경고가 뜰 수 있습니다.
"추가 정보 → 실행"을 선택해 주세요.
